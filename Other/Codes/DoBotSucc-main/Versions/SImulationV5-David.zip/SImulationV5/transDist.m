function dist = transDist(t1,t2)
    td = t1-t2;
    dist = norm(td(1:3,4));
    
end%end transDist